/*
  ALPHA CDI - ESP32-C3 BLE monitor/configuration prototype
  IMPORTANT:
  - This firmware is MONITOR/CONFIGURATION ONLY.
  - It does NOT drive an ignition coil, CDI capacitor, SCR, injector or spark output.
  - GPIO inputs must receive conditioned, protected 3.3V logic signals only.
  - Never connect pickup-coil, stator, ignition-coil or CDI high-voltage wiring directly.
  - Verify board pin mapping and signal conditioner before connecting to a running engine.
  Library: NimBLE-Arduino 2.x
*/

#include <Arduino.h>
#include <NimBLEDevice.h>
#include <Preferences.h>

static const char* DEVICE_NAME = "alpha zs190";
static const char* SERVICE_UUID   = "7b7e0001-6d2a-4f7a-9c31-414c50484100";
static const char* TELEMETRY_UUID= "7b7e0002-6d2a-4f7a-9c31-414c50484100";
static const char* COMMAND_UUID  = "7b7e0003-6d2a-4f7a-9c31-414c50484100";

// Suggested ESP32-C3 pins. Use ONLY conditioned 0-3.3V logic signals.
static constexpr int PIN_MARK_START = 1;
static constexpr int PIN_MARK_END   = 0;
static constexpr int PIN_DC_STATUS  = 3;
static constexpr int PIN_SPARK_FB   = 4; // feedback monitor input, NOT an ignition output

volatile uint32_t pulseCount = 0;
volatile uint32_t lastPulseUs = 0;
volatile uint32_t lastWidthUs = 0;
volatile bool startLevel = false;
volatile bool endLevel = false;

NimBLECharacteristic* telemetryChar = nullptr;
Preferences prefs;
uint32_t limiterRpm = 11000;
String cutMode = "FULL";
bool swapInputs = false;
uint32_t lastReportMs = 0;
uint32_t rpm = 0;

void IRAM_ATTR onStartEdge() {
  uint32_t now = micros();
  if (lastPulseUs != 0) lastWidthUs = now - lastPulseUs;
  lastPulseUs = now;
  pulseCount++;
}

class CommandCallbacks : public NimBLECharacteristicCallbacks {
  void onWrite(NimBLECharacteristic* c, NimBLEConnInfo& connInfo) override {
    std::string raw = c->getValue();
    if (raw.empty()) return;
    String s(raw.c_str());
    if (s.indexOf("\"cmd\":\"get\"") >= 0) {
      sendSettings();
      return;
    }
    if (s.indexOf("\"cmd\":\"set\"") >= 0) {
      long v = jsonInt(s, "limiter", limiterRpm);
      if (v >= 4000 && v <= 14000) limiterRpm = (uint32_t)v;
      String m = jsonString(s, "mode", cutMode);
      if (m == "FULL" || m == "INTERMITTENT" || m == "OFF") cutMode = m;
      swapInputs = s.indexOf("\"swap\":true") >= 0;
      prefs.putUInt("limiter", limiterRpm);
      prefs.putString("mode", cutMode);
      prefs.putBool("swap", swapInputs);
      sendSettings();
    }
  }
};

long jsonInt(const String& s, const char* key, long fallback) {
  String k = String("\"") + key + "\":";
  int p = s.indexOf(k);
  if (p < 0) return fallback;
  p += k.length();
  while (p < (int)s.length() && s[p] == ' ') p++;
  int e = p;
  while (e < (int)s.length() && (isDigit(s[e]) || s[e] == '-')) e++;
  return s.substring(p, e).toInt();
}

String jsonString(const String& s, const char* key, const String& fallback) {
  String k = String("\"") + key + "\":\"";
  int p = s.indexOf(k);
  if (p < 0) return fallback;
  p += k.length();
  int e = s.indexOf('"', p);
  if (e < 0) return fallback;
  return s.substring(p, e);
}

void sendSettings() {
  if (!telemetryChar) return;
  String out = "{\"type\":\"settings\",\"limiter\":" + String(limiterRpm) +
    ",\"mode\":\"" + cutMode + "\",\"swap\":" + (swapInputs ? "true" : "false") + "}";
  telemetryChar->setValue(out.c_str());
  telemetryChar->notify();
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_MARK_START, INPUT_PULLUP);
  pinMode(PIN_MARK_END, INPUT_PULLUP);
  pinMode(PIN_DC_STATUS, INPUT_PULLUP);
  pinMode(PIN_SPARK_FB, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(PIN_MARK_START), onStartEdge, FALLING);

  prefs.begin("alpha-cdi", false);
  limiterRpm = prefs.getUInt("limiter", 11000);
  cutMode = prefs.getString("mode", "FULL");
  swapInputs = prefs.getBool("swap", false);

  NimBLEDevice::init(DEVICE_NAME);
  NimBLEServer* server = NimBLEDevice::createServer();
  NimBLEService* service = server->createService(SERVICE_UUID);
  telemetryChar = service->createCharacteristic(
    TELEMETRY_UUID, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY);
  NimBLECharacteristic* commandChar = service->createCharacteristic(
    COMMAND_UUID, NIMBLE_PROPERTY::WRITE | NIMBLE_PROPERTY::WRITE_NR);
  commandChar->setCallbacks(new CommandCallbacks());
  telemetryChar->setValue("{\"type\":\"boot\",\"rpm\":0}");
  service->start();
  NimBLEAdvertising* advertising = NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->start();
}

void loop() {
  const uint32_t nowMs = millis();
  if (nowMs - lastReportMs >= 100) {
    lastReportMs = nowMs;

    uint32_t count, width, last;
    noInterrupts();
    count = pulseCount;
    pulseCount = 0;
    width = lastWidthUs;
    last = lastPulseUs;
    interrupts();

    // Assumes one conditioned pulse per crank revolution.
    // Change pulsesPerRevolution only after verifying the pickup/trigger pattern.
    const float pulsesPerRevolution = 1.0f;
    rpm = (uint32_t)((count * 600.0f) / pulsesPerRevolution); // 100 ms window
    if (count == 0 && (micros() - last) > 500000UL) rpm = 0;

    bool start = digitalRead(PIN_MARK_START) == HIGH;
    bool end = digitalRead(PIN_MARK_END) == HIGH;
    if (swapInputs) { bool t = start; start = end; end = t; }
    bool dc = digitalRead(PIN_DC_STATUS) == HIGH;
    bool sparkFb = digitalRead(PIN_SPARK_FB) == HIGH;

    if (telemetryChar) {
      String json = "{\"type\":\"telemetry\",\"rpm\":" + String(rpm) +
        ",\"width_us\":" + String(width) +
        ",\"start\":" + String(start ? "true" : "false") +
        ",\"end\":" + String(end ? "true" : "false") +
        ",\"dc\":" + String(dc ? "true" : "false") +
        ",\"spark_fb\":" + String(sparkFb ? "true" : "false") +
        ",\"limiter\":" + String(limiterRpm) +
        ",\"mode\":\"" + cutMode + "\"}";
      telemetryChar->setValue(json.c_str());
      telemetryChar->notify();
    }
  }
  delay(2);
}
