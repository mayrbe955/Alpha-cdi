import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:permission_handler/permission_handler.dart';

const serviceUuid = '7b7e0001-6d2a-4f7a-9c31-414c50484100';
const telemetryUuid = '7b7e0002-6d2a-4f7a-9c31-414c50484100';
const commandUuid = '7b7e0003-6d2a-4f7a-9c31-414c50484100';

const bg = Color(0xFF08111F);
const panel = Color(0xFF111F30);
const border = Color(0xFF26384B);
const mint = Color(0xFF42D6B5);
const blue = Color(0xFF59B8F5);
const yellow = Color(0xFFFFC65C);
const pink = Color(0xFFFF79A8);

void main() => runApp(const AlphaCdiApp());

class AlphaCdiApp extends StatelessWidget {
  const AlphaCdiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'ALPHA CDI',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: mint, surface: panel),
      textTheme: ThemeData.dark().textTheme.apply(
        bodyColor: const Color(0xFFE8F0F8),
        displayColor: const Color(0xFFE8F0F8),
      ),
    ),
    home: const DashboardPage(),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late final TabController tabs = TabController(length: 2, vsync: this);
  BluetoothDevice? device;
  BluetoothCharacteristic? telemetry;
  BluetoothCharacteristic? command;
  StreamSubscription<List<int>>? notifySub;
  StreamSubscription<List<ScanResult>>? scanSub;
  bool scanning = false;
  String connection = 'Не подключено';
  int rpm = 0;
  int markWidth = 0;
  bool inputStart = false, inputEnd = false, dcReady = false, sparkFeedback = false;
  int limiter = 11000;
  String cutMode = 'FULL';
  bool swapInputs = false;
  final List<FlSpot> points = [];
  int sample = 0;
  final devices = <ScanResult>[];

  @override
  void dispose() {
    tabs.dispose();
    notifySub?.cancel();
    scanSub?.cancel();
    super.dispose();
  }

  Future<void> scan() async {
    final permissions = await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.locationWhenInUse,
    ].request();
    if (permissions.values.any((p) => p.isDenied || p.isPermanentlyDenied)) {
      if (mounted) setState(() => connection = 'Разрешите Bluetooth в настройках Android');
      return;
    }
    setState(() { scanning = true; devices.clear(); connection = 'Поиск устройств…'; });
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 8));
      scanSub?.cancel();
      scanSub = FlutterBluePlus.scanResults.listen((results) {
        if (!mounted) return;
        setState(() {
          for (final r in results) {
            if ((r.device.platformName.toLowerCase().contains('alpha') ||
                 r.device.platformName.toLowerCase().contains('cdi')) &&
                !devices.any((x) => x.device.remoteId == r.device.remoteId)) {
              devices.add(r);
            }
          }
        });
      });
      await Future.delayed(const Duration(seconds: 8));
    } catch (e) {
      if (mounted) setState(() => connection = 'Ошибка Bluetooth: $e');
    }
    if (mounted) setState(() { scanning = false; if (devices.isEmpty && device == null) connection = 'Устройство не найдено'; });
  }

  Future<void> connect(BluetoothDevice d) async {
    try {
      await d.connect(timeout: const Duration(seconds: 12), autoConnect: false);
    } catch (_) {}
    try {
      final services = await d.discoverServices();
      BluetoothService? s;
      for (final item in services) {
        if (item.uuid.toString().toLowerCase() == serviceUuid) { s = item; break; }
      }
      if (s == null) throw Exception('Сервис ALPHA CDI не найден');
      telemetry = s.characteristics.firstWhere((x) => x.uuid.toString().toLowerCase() == telemetryUuid);
      command = s.characteristics.firstWhere((x) => x.uuid.toString().toLowerCase() == commandUuid);
      await telemetry!.setNotifyValue(true);
      notifySub?.cancel();
      notifySub = telemetry!.onValueReceived.listen(parseTelemetry);
      if (!mounted) return;
      setState(() { device = d; connection = 'Подключено · BLE готов'; });
      await send({'cmd':'get'});
    } catch (e) {
      if (mounted) setState(() => connection = 'Ошибка подключения: $e');
    }
  }

  void parseTelemetry(List<int> bytes) {
    try {
      final j = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        rpm = (j['rpm'] ?? 0) as int;
        markWidth = (j['width_us'] ?? 0) as int;
        inputStart = j['start'] == true;
        inputEnd = j['end'] == true;
        dcReady = j['dc'] == true;
        sparkFeedback = j['spark_fb'] == true;
        if (points.length > 55) points.removeAt(0);
        points.add(FlSpot(sample++.toDouble(), rpm.toDouble()));
      });
    } catch (_) {}
  }

  Future<void> send(Map<String, dynamic> data) async {
    if (command == null) return;
    await command!.write(utf8.encode(jsonEncode(data)), withoutResponse: false);
  }

  Future<void> saveSettings() async {
    await send({'cmd':'set', 'limiter':limiter, 'mode':cutMode, 'swap':swapInputs});
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Настройки отправлены в коммутатор')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: bg, elevation: 0,
      title: const Text('alpha zs190', style: TextStyle(fontWeight: FontWeight.w700)),
      actions: [IconButton(onPressed: scanning ? null : scan,
        icon: Icon(scanning ? Icons.bluetooth_searching : Icons.bluetooth, color: mint))],
      bottom: TabBar(controller: tabs, indicatorColor: mint, labelColor: mint,
        unselectedLabelColor: Colors.white60, tabs: const [
          Tab(text:'Монитор'), Tab(text:'Налаштування')
        ]),
    ),
    body: TabBarView(controller: tabs, children: [monitorPage(), settingsPage()]),
  );

  Widget monitorPage() => ListView(padding: const EdgeInsets.all(16), children: [
    Text(connection, style: const TextStyle(color: Colors.white60)),
    const SizedBox(height: 14),
    if (device == null && devices.isNotEmpty) card(Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Найденные устройства', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ...devices.map((r) => ListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(r.device.platformName.isEmpty ? 'ESP32-C3' : r.device.platformName),
          subtitle: Text(r.device.remoteId.str),
          trailing: TextButton(onPressed: () => connect(r.device), child: const Text('Подключить')),
        ))
      ])),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('ОБЕРТИ ДВИГУНА', style: TextStyle(color: Colors.white60, letterSpacing: 1)),
      const SizedBox(height: 4),
      Text('$rpm', style: const TextStyle(fontSize: 64, height: 1, color: mint, fontWeight: FontWeight.bold)),
      const Text('об/мин', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 12),
      Row(children: [
        const Icon(Icons.circle, color: yellow, size: 9),
        const SizedBox(width: 7),
        Text(device == null ? 'Ожидание подключения' : 'BLE-график готовый', style: const TextStyle(color: Colors.white70)),
      ]),
      Text('Ширина метки: $markWidth мкс', style: const TextStyle(color: Colors.white60)),
    ])),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.75,
      children: [
        statusCard('GPIO1 · начало', inputStart ? 'HIGH' : 'LOW', mint),
        statusCard('GPIO0 · конец', inputEnd ? 'HIGH' : 'LOW', blue),
        statusCard('DC-DC · GPIO3', dcReady ? 'Работает · HIGH' : 'Нет сигнала', yellow),
        statusCard('Искра · GPIO4', sparkFeedback ? 'Есть feedback' : 'Нет feedback', pink),
      ]),
    const SizedBox(height: 12),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        const Text('Сигналы / RPM', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text('${points.length} точек', style: const TextStyle(color: Colors.white54)),
      ]),
      const SizedBox(height: 16),
      SizedBox(height: 170, child: points.length < 2
        ? const Center(child: Text('Ожидание данных от ESP32', style: TextStyle(color: Colors.white54)))
        : LineChart(LineChartData(
          minY: 0, maxY: 12000, gridData: const FlGridData(show: true, drawVerticalLine: true),
          titlesData: const FlTitlesData(show: false),
          borderData: FlBorderData(show: false),
          lineBarsData: [LineChartBarData(spots: List.of(points), isCurved: false,
            color: mint, barWidth: 2, dotData: const FlDotData(show: false))],
        ))),
      const Text('График обновляется при получении телеметрии', style: TextStyle(color: Colors.white54, fontSize: 12)),
    ])),
    const SizedBox(height: 18),
    OutlinedButton.icon(onPressed: scan, icon: const Icon(Icons.bluetooth_searching), label: const Text('Найти коммутатор')),
  ]);

  Widget settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    Text(connection, style: const TextStyle(color: Colors.white60)),
    const SizedBox(height: 14),
    card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Параметри відсічки', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Text('Текущие: $limiter об/мин · Задано: $limiter об/мин'),
      const SizedBox(height: 18),
      const Text('Полная отсечка, об/мин', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 8),
      Text('$limiter', style: const TextStyle(fontSize: 25, color: mint, fontWeight: FontWeight.bold)),
      Slider(value: limiter.toDouble(), min: 4000, max: 14000, divisions: 100,
        activeColor: mint, onChanged: (v) => setState(() => limiter = v.round())),
      const SizedBox(height: 8),
      const Text('Режим', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: cutMode, dropdownColor: panel,
        decoration: const InputDecoration(border: OutlineInputBorder()),
        items: const [
          DropdownMenuItem(value:'FULL', child:Text('Полная отсечка')),
          DropdownMenuItem(value:'INTERMITTENT', child:Text('Интервальная отсечка')),
          DropdownMenuItem(value:'OFF', child:Text('Отключено (только мониторинг)')),
        ],
        onChanged: (v) => setState(() => cutMode = v ?? 'FULL'),
      ),
      SwitchListTile(contentPadding: EdgeInsets.zero, activeColor: mint,
        title: const Text('Поменять входы местами'),
        value: swapInputs, onChanged: (v) => setState(() => swapInputs = v)),
      const Text('GPIO1 — начало метки, GPIO0 — конец метки.', style: TextStyle(color: Colors.white54)),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton(
        style: FilledButton.styleFrom(backgroundColor: mint, foregroundColor: bg, padding: const EdgeInsets.all(17)),
        onPressed: device == null ? null : saveSettings,
        child: const Text('Применить и сохранить', style: TextStyle(fontWeight: FontWeight.bold)))),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, child: OutlinedButton(
        onPressed: device == null ? null : () => send({'cmd':'get'}),
        child: const Text('Перечитать из коммутатора'))),
      const SizedBox(height: 8),
      const Text('Настройки сохраняются в памяти ESP32. Управление силовым выходом CDI в этой версии не реализовано.',
        style: TextStyle(color: mint, fontSize: 12)),
    ])),
    const SizedBox(height: 12),
    card(const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Зажигание', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      SizedBox(height: 10),
      Text('Ширина импульса искры: мониторинг не подключён'),
      SizedBox(height: 8),
      Text('Угол опережения: не настроен'),
      SizedBox(height: 8),
      Text('DC-DC после остановки: только индикация'),
    ])),
  ]);

  Widget statusCard(String title, String value, Color color) => card(Column(
    crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center,
    children: [Text(title, style: const TextStyle(color: Colors.white60, fontSize: 13)),
      const SizedBox(height: 8), Text(value, style: TextStyle(color: color, fontSize: 17, fontWeight: FontWeight.bold))],
  ));

  Widget card(Widget child) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, border: Border.all(color: border),
      borderRadius: BorderRadius.circular(22)),
    child: child,
  );
}
